#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import time

import subprocess
subprocess.call("python bot.py", shell=True)
subprocess.call("echo kir", shell=True)
